package org.zerock.guestbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProjectForSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
